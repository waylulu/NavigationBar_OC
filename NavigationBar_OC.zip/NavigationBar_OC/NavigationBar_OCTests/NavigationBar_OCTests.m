//
//  NavigationBar_OCTests.m
//  NavigationBar_OCTests
//
//  Created by 朱路路 on 16/5/13.
//  Copyright © 2016年 朱路路. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface NavigationBar_OCTests : XCTestCase

@end

@implementation NavigationBar_OCTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
